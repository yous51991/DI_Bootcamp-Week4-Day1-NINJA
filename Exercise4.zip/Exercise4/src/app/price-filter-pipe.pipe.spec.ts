import { PriceFilterPipePipe } from './price-filter-pipe.pipe';

describe('PriceFilterPipePipe', () => {
  it('create an instance', () => {
    const pipe = new PriceFilterPipePipe();
    expect(pipe).toBeTruthy();
  });
});
