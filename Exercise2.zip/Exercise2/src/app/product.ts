export class Product {
	nom: string
	prix:  number
}
