export type  product  = {
  name :string ;
  price : number;
  category : string
}
