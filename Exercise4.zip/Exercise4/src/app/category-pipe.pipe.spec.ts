import { CategoryPipePipe } from './category-pipe.pipe';

describe('CategoryPipePipe', () => {
  it('create an instance', () => {
    const pipe = new CategoryPipePipe();
    expect(pipe).toBeTruthy();
  });
});
